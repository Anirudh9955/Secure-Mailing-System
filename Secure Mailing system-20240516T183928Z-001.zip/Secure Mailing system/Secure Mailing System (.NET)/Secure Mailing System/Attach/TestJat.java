

        interface    JatCommunity
            {
                public     void  marriage();
            }


            class  TestJat
                {
                    public static void main( String ags[] )
                         {

                               JatCommunity   jobj   = new JatCommunity()
                                                                          {
                                                                   public     void  marriage()
                                                                               {    System.out.println("  love  marriage");  }
                                                                          };
                                    jobj.marriage();
                         }                                
                }