using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class account : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Button1.Enabled = true;
            Label9.Visible = false;
            Button2.Enabled = false;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        chktext();
        if (Label9.Text == "continue")
        {
            fill();
        }
        else
        {
            Label9.Visible = true;
        }
    }
    public void fill()
    {
        string dob = "" + ddl_date.Text + "/" + ddl_mon.Text + "/" + ddl_year.Text + "";
        c.con.Open();
        string abc = "insert into user_det(u_id,u_fname,u_lname,u_pass,u_dob,u_gen,u_pcode,u_add,u_cno,u_dttm,u_block) values('" + txt_eid.Text + "','" + txt_fname.Text + "','" + txt_lname.Text + "','" + txt_pwd.Text + "','" + dob + "','" + RadioButtonList1.Text + "','" + txt_postal.Text + "','" + txt_add.Text + "','" + txt_cno.Text + "','" + System.DateTime.Now + "','n')";
        SqlCommand cmd = new SqlCommand(abc, c.con);
        cmd.ExecuteNonQuery();
        c.con.Close();
        Session["uid"] = txt_eid.Text;
        Session["uname"] = txt_fname.Text;
        Response.Redirect("ulogmain.aspx");
    }
    public void chktext()
    {
        if (Label9.Text != "")
        {
            Label9.Text = "";
        }
        if (txt_pwd.Text == "")
        {
            ViewState["text"] = "Fill the Password";
            goto done;         
        }
        if (txt_fname.Text == "")
        {
            ViewState["text"] = "Fill the First Name";
            goto done;
        }
        if (txt_lname.Text == "")
        {
            ViewState["text"] = "Fill the Last Name";
            goto done;
        }
        if (txt_add.Text == "")
        {
            ViewState["text"] = "Fill the Address";
            goto done;
        }
        if (txt_cno.Text == "")
        {
            ViewState["text"] = "Fill the Contact No.";
            goto done;
        }       
        if (ddl_date.Text == "n")
        {
            ViewState["text"] = "Select the Date";
            goto done;
        }
        if (ddl_mon.Text == "n")
        {
            ViewState["text"] = "Select the Month";
            goto done;
        }
        if (ddl_year.Text == "n")
        {
            ViewState["text"] = "Select the Year";
            goto done;
        }        
        if (RadioButtonList1.Text == "")
        {
            ViewState["text"] = "Select the Gender";
            goto done;
        }
        if (txt_postal.Text == "")
        {
            ViewState["text"] = "Fill the Postal Code";
            goto done;
        }
        if (txt_ver.Text == "")
        {
            ViewState["text"] = "Fill the Verification Code";
            goto done;
        }
        if (txt_ver.Text != "dedl")
        {
            ViewState["text"] = "Fill the Correct Postal Code";
            goto done;
        }
        if (Label9.Text == "")
        {
            ViewState["text"] = "continue";
        }
    done:
        Label9.Visible = true;
        Label9.Text = ViewState["text"].ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txt_eid.Text == "")
        {
            Label9.Visible = true;
            Label9.Text = "Please enter ur Email ID";
        }
        else
        {
            chkid();
        }
    }
    public void chkid()
    {
        c.con.Open();
        string abc = "select u_id from user_det";
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label9.Text = "Continue....!!";
            if (txt_eid.Text == dr["u_id"].ToString())
            {
                Label9.Visible = true;
                Label9.Text = "Email ID Already Exists...!!";
                Button1.Enabled = true;
                Button2.Enabled = false;
                txt_eid.ReadOnly = false;
            }
            else
            {
                Label9.Visible = true;
                Label9.Text = "Continue ....!!";
                Button1.Enabled = false;
                Button2.Enabled = true;
                txt_eid.ReadOnly = true;
                while (dr.Read())
                {
                    if (txt_eid.Text == dr["u_id"].ToString())
                    {
                        Label9.Visible = true;
                        Label9.Text = "Email ID Already Exists...!!";
                        Button1.Enabled = true;
                        Button2.Enabled = false;
                        txt_eid.ReadOnly = false;
                        goto done;
                    }
                    else
                    {
                        Label9.Visible = true;
                        Label9.Text = "Continue ....!!";
                        Button1.Enabled = false;
                        Button2.Enabled = true;
                        txt_eid.ReadOnly = true;
                    }
                }
            }
        done:
            Label9.Visible = true;
//            Label9.Text = ViewState["text"].ToString();
        }
        else
        {
            Label9.Visible = true;
            Label9.Text = "Continue ....!!";
            Button2.Enabled = true;
            txt_eid.ReadOnly = true;
        }
        c.con.Close();
    }
}
