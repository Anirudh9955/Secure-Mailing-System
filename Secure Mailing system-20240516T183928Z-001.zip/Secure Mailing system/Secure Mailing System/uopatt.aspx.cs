using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class uopatt : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            chkfile();
            docopen();
        }
    }
    public void chkfile()
    {
        string abc = "select * from usr_mail where m_id=" + Request.QueryString["mid"];
        c.con.Open();
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        dr.Read();
        string strFileName = dr["m_att"].ToString();
        ViewState["fullname"] = strFileName;
        strFileName = strFileName.Substring(strFileName.LastIndexOf(".") + 1);
        ViewState["fileex"] = strFileName.ToString();
        c.con.Close();
    }
    public void docopen()
    {
        string strRequest = "Attach/"+ViewState["fullname"].ToString();
        if (strRequest != "")
        {
            string path = Server.MapPath(strRequest);
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            {
                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                Response.AddHeader("Content-Length", file.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.WriteFile(file.FullName);
                Response.End();
            }
            else
            {         
                Response.Write("This file does not exist.");
            }
        }
        else
        {
            Response.Write("Please provide a file to download.");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}
