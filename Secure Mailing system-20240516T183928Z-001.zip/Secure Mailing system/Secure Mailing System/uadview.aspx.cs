using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class uadview : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (!Page.IsPostBack)
        {
            Label1.Visible = false;
            GridView1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            RequiredFieldValidator1.Visible = false;
            TextBox1.Visible = false;
            Button1.Visible = false;
        }
        if (Request.QueryString["dfid"] == null)
        {
            Button1.Visible = false;
            GridView1.Visible = true;
            gd();
            Label2.Visible = false;
            Label3.Visible = false;
            RequiredFieldValidator1.Visible = false;
            TextBox1.Visible = false;
            Label1.Visible = true;
        }
        else
        {
            Label1.Visible = false;
            chk();
            Button1.Visible = true;
            GridView1.Visible = false;
            Label2.Visible = true;
            Label2.Text = "Selected Topic is :" + ViewState["topic"].ToString() + ".";
            Label3.Visible = true;
            RequiredFieldValidator1.Visible = true;
            TextBox1.Visible = true;
        }
    }
    public void chk()
    {
        c.con.Open();
        string str = "select * from df_topic where dft_id=" + Request.QueryString["dfid"];
        SqlCommand cmd = new SqlCommand(str, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        dr.Read();
            ViewState["topic"] = dr["dft_topic"].ToString();
            dr.Close();
        c.con.Close();
    }
    public void gd()
    {
        c.con.Open();
        string str = "select * from df_topic";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = e.Row.Cells[2].Text + "@secure.com";
            e.Row.Cells[1].Text = "<a href=uadview.aspx?dfid=" + e.Row.Cells[0].Text + ">" + e.Row.Cells[1].Text + "</a>".ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.con.Open();
        string comment = TextBox1.Text.Replace("'", "''");
        string str = "insert into df_views(dfv_uid,dfv_dft_id,dfv_views,dfv_dttm) values('" + Session["uid"].ToString() + "','" + Request.QueryString["dfid"].ToString() + "','" + comment + "','" + System.DateTime.Now + "')";
        SqlCommand cmd = new SqlCommand(str, c.con);
        cmd.ExecuteNonQuery();
        c.con.Close();
        Button1.Enabled = false;
    }
}
