using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

public partial class uopdfmail : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Request.QueryString["mid"] != null)
        {
            if (!Page.IsPostBack)
            {
                attachFile1.Visible = false;
                Label3.Visible = false;
                fill();
                Button1.Enabled = false;
            }
        }
    }
    public void fill()
    {
        c.con.Open();
        string abc = "select * from usr_mail where m_id=" + Request.QueryString["mid"].ToString();
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txt_mailto.Text = dr["m_rec"].ToString();
            txt_mailsub.Text = dr["m_sub"].ToString();
            txt_mailmsg.Text = dr["m_mail"].ToString();
            ViewState ["att"] = dr["m_att"].ToString();
            Label3.Text = dr["m_att"].ToString();
        }
        if (ViewState ["att"] == null)
        {
            attachFile1.Visible = true;
            ViewState ["att"] = false;
        }
        else
        {
            attachFile1.Visible = false;
            Label3.Visible = true;
        }
        c.con.Close();
    }
    public void sendout()
    {
        string type = "o";
        c.con.Open();
        string atr = "update usr_mail set m_type='" + type + "',m_rec='" + txt_mailto.Text + "',m_sen='" + Session["uid"].ToString() + "',m_att='" + ViewState["att"].ToString() + "',m_rsamail='" + txt_mailenmsg.Text + "',m_mail='"+Label11 .Text+"',m_dttm='" + System.DateTime.Now + "',m_sub='" + txt_mailsub.Text + "' where m_id='" + Request.QueryString["mid"].ToString() + "'";
        SqlCommand cmd = new SqlCommand(atr, c.con);
        cmd.ExecuteNonQuery();
        c.con.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        vis();
    }
    public void vis()
    {
        if ((TextBox1.Text == "2" || TextBox1.Text == "3" || TextBox1.Text == "5" || TextBox1.Text == "7" || TextBox1.Text == "11" || TextBox1.Text == "13" || TextBox1.Text == "17" || TextBox1.Text == "19") && (TextBox2.Text == "2" || TextBox2.Text == "3" || TextBox2.Text == "5" || TextBox2.Text == "7" || TextBox2.Text == "11" || TextBox2.Text == "13" || TextBox2.Text == "17" || TextBox2.Text == "19"))
        {
            if (TextBox1.Text != TextBox2.Text)
            {
                chk();
                chkatt();
                Button1.Enabled = true;
                Button5.Enabled = false;
                RSACryptoServiceProvider myrsa = new RSACryptoServiceProvider();
                System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
                string data = txt_mailmsg.Text;
                Byte[] newdata = encoding.GetBytes(data);
                Byte[] encrypted = myrsa.Encrypt(newdata, false);
                for (int i = 0; i < encrypted.Length; i++)
                {
                    string s = encrypted[i].ToString();
                    Label6.Text = Label6.Text + s.ToString();
                }
                txt_mailenmsg.Text = Label6.Text;
                Label6.Text = "";                
                Label3.Visible = true;
                Label3.Text = ViewState["att"].ToString();
                attachFile1.Visible = false;
                Label6.Visible = false;
                ViewState["pass"] = TextBox3.Text;
            }
            else
            {
                Label6.Visible = true;
                Label6.Text = "Both prime no should not same";
            }
        }
        else
        {
            Label6.Visible = true;
            Label6.Text = "Please enter valid Prime no";
        }
    }
    public void insert()
    {
        Label11.Visible = true;
        Label11.Text = "";
        string myData = txt_mailmsg.Text;
        string myDataEncoded = EncodeTo64(myData);
        Label11.Text = myDataEncoded.ToString();        
    }
    public void chk()
    {
        c.con.Open();
        string abc = "select u_id from user_det where u_id='" + txt_mailto.Text + "'";
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
            ViewState["chk"] = "y";
        else
            ViewState["chk"] = "n";
        dr.Close();
        c.con.Close();
    }
    static public string EncodeTo64(string toEncode)
    {
        byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);
        string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
        return returnValue;
    }
    static public string DecodeFrom64(string encodedData)
    {
        byte[] encodedDataAsBytes = System.Convert.FromBase64String(encodedData);
        string returnValue = System.Text.ASCIIEncoding.ASCII.GetString(encodedDataAsBytes);
        return returnValue;
    }
    public void nwmal()
    {
        String Filename1 = System.DateTime.Now.Day.ToString();
        Filename1 = Filename1 + "-" + System.DateTime.Now.Month.ToString();
        Filename1 = Filename1 + "-" + System.DateTime.Now.Year.ToString();
        c.con.Open();
        string str = "select * from usr_mail where m_rec='" + txt_mailto.Text + "' and m_fuldt='" + Filename1.ToString() + "' order by m_id";
        SqlCommand cmd = new SqlCommand(str, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        int i = 1;
        while (dr.Read())
        {
            i = i + 1;
        }
        String Filename = System.DateTime.Now.Day.ToString();
        Filename = Filename + "-" + System.DateTime.Now.Month.ToString();
        Filename = Filename + "-" + System.DateTime.Now.Year.ToString();
        ViewState["fname"] = Filename + " (" + i + ")";
        c.con.Close();
        string att = ConfigurationSettings.AppSettings["path"].ToString();
        System.IO.Directory.CreateDirectory(att);
        string path = att + "" + txt_mailto.Text;
        System.IO.Directory.CreateDirectory(path);
        string Filepath = path + "/" + ViewState["fname"].ToString() + ".txt";
        if (Label3.Text == "n")
            ViewState["att1"] = "No";
        else
            ViewState["att1"] = "Yes";
        string content = "From: " + Session["uid"].ToString() + "\r\n\r\nSubject: " + txt_mailsub.Text + "\r\n\r\nAttachment: " + ViewState["att1"].ToString() + "\r\n\r\nMessage: " + txt_mailmsg.Text + "";
        StreamWriter swcontent = new StreamWriter(Filepath);
        swcontent.Write(content);
        File.SetAttributes(Filepath, FileAttributes.ReadOnly);
        swcontent.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        chk();
        if (ViewState["chk"].ToString() == "y")
        {
            nwmal();
            insert();
            string type = "i";
            string fuldt = System.DateTime.Now.Day.ToString() + "-" + System.DateTime.Now.Month.ToString() + "-" + System.DateTime.Now.Year.ToString();
            c.con.Open();
            string abc123 = "insert into usr_mail(m_type,m_rec,m_sen,m_att,m_mail,m_rsamail,m_dttm,m_sub,m_pass,m_fuldt) values('" + type + "','" + txt_mailto.Text + "','" + Session["uid"].ToString() + "','" + Label3.Text + "','" + Label11.Text + "','" + txt_mailenmsg.Text + "','" + System.DateTime.Now + "','" + txt_mailsub.Text + "','" + ViewState["pass"].ToString() + "','" + fuldt + "')";
            SqlCommand cmd1 = new SqlCommand(abc123, c.con);
            cmd1.ExecuteNonQuery();
            c.con.Close();
            sendout();
            Response.Redirect("ulogmain.aspx");
        }
        if (ViewState["chk"].ToString() == "n")
        {
            Label6.Visible = true;
            Label6.Text = "There is no such ID in Secure Database..!!";
        }
    }
    public void chkatt()
    {
        if (attachFile1.Value.ToString() != "")
        {
            string str = attachFile1.PostedFile.FileName;
            str = System.IO.Path.GetFileName(str);
            string path = Server.MapPath("~/Attach/") + str;
            attachFile1.PostedFile.SaveAs(path);
            Label3.Text = str;
        }
        else
        {
            string str = "n";
            Label3.Text = str;
        }
    }
}
