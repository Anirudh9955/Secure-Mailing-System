using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class udisform : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (!Page.IsPostBack)
        {
            TextBox1.Text = "";
            Label2.Visible = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        c.con.Open();
        string comment = TextBox1.Text.Replace("'", "''");
        string abc = "insert into df_topic(dft_uid,dft_topic,dft_dttm) values('" + Session["uid"].ToString() + "','" + comment + "','" + System.DateTime.Now + "')";
        SqlCommand cmd = new SqlCommand(abc, c.con);
        cmd.ExecuteNonQuery();
        c.con.Close();
        Label2.Visible = true;
        Label2.Text = "New Topic Inserted ..!!";
        Button1.Enabled = false;
    }
}
