using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class usearch : System.Web.UI.Page
{

    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }

    }
    public void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "em")
        {
            Label1.Visible = true;
            TextBox1.Visible = true;
            Button1.Visible = true;
            Label1.Text = "Enter E-Mail Id:";
            Label3.Visible = true;
            ViewState["sel"] = RadioButtonList1.SelectedValue.ToString();
            GridView1.Visible = false;
            TextBox1.Text = "";
            Label2.Visible = false;
        }
        if (RadioButtonList1.SelectedValue == "sub")
        {
            TextBox1.Text = "";
            GridView1.Visible = false;
            Label3.Visible = false;
            Label1.Visible = true;
            TextBox1.Visible = true;
            Button1.Visible = true;
            Label1.Text = "Enter E-Mail Subject:";
            ViewState["sel"] = RadioButtonList1.SelectedValue.ToString();
            Label2.Visible = false;
        }
    }
    public void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            Label2.Visible = true;
            Label2.Text = "!!..Please enter the search text..!!";
        }
        else
        {
            if (ViewState["sel"].ToString() == "em")
            {
                c.con.Open();
                string str = "select * from user_det, usr_mail where u_id='" + Session["uid"].ToString() + "' and m_type='i' and u_id=m_rec and m_sen='" + TextBox1.Text + "' order by m_dttm desc";
                SqlCommand cmd = new SqlCommand(str, c.con);
                SqlDataReader dr = cmd.ExecuteReader();
                int i = 1;
                while (dr.Read())
                {
                    i = i + 1;
                    ViewState["no"] = i.ToString();

                }
                if (Convert.ToInt32(ViewState["no"]) > 1)
                {
                    GridView1.Visible = true;
                    Label2.Visible = false;
                }
                else
                {
                    GridView1.Visible = false;
                    Label2.Visible = true;
                    Label2.Text = "There is no mail from " + TextBox1.Text + "@secure.com";
                }
                c.con.Close();
                c.con.Open();
                string str1 = "select * from user_det, usr_mail where u_id='" + Session["uid"].ToString() + "' and m_type='i' and u_id=m_rec and m_sen='" + TextBox1.Text + "' order by m_dttm desc";
                SqlDataAdapter ad = new SqlDataAdapter(str1, c.con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
                c.con.Close();
            }
            if (ViewState["sel"].ToString() == "sub")
            {
                c.con.Open();
                string str = "select * from user_det, usr_mail where u_id='" + Session["uid"].ToString() + "' and m_type='i' and u_id=m_rec and m_sub like '%" + TextBox1.Text + "%' order by m_dttm desc";
                SqlCommand cmd = new SqlCommand(str, c.con);
                SqlDataReader dr = cmd.ExecuteReader();
                int i = 1;
                while (dr.Read())
                {
                    i = i + 1;
                    ViewState["no"] = i.ToString();
                }
                if (Convert.ToInt32(ViewState["no"]) > 1)
                {
                    GridView1.Visible = true;
                    Label2.Visible = false;
                }
                else
                {
                    GridView1.Visible = false;
                    Label2.Visible = true;
                    Label2.Text = "No mails found with the entered subject";
                }
                c.con.Close();
                c.con.Open();
                string str1 = "select * from user_det, usr_mail where u_id='" + Session["uid"].ToString() + "' and m_type='i' and u_id=m_rec and m_sub like '%" + TextBox1.Text + "%' order by m_dttm desc";
                SqlDataAdapter ad = new SqlDataAdapter(str1, c.con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
                c.con.Close();
            }
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[3].Text = e.Row.Cells[3].Text + "@secure.com";
            e.Row.Cells[2].Text = "<a href=uopinmail.aspx?mid=" + e.Row.Cells[1].Text + ">" + e.Row.Cells[2].Text + "</a>".ToString();
        }
    }
}
