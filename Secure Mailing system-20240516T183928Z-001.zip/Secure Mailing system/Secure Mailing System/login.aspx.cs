using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Label4.Visible = false;
        }
        if (Request.QueryString["log"] != null)
        {
            Label4.Visible = true;
            Label4.Text = "Please Login into your account";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txt_uname.Text == "admin" && txt_pass.Text == "a")
        {
            Session["uid"] = "Admin";
            Response.Redirect("adminlog.aspx");
        }
        else
        {
            c.con.Open();
            string abc = "select * from user_det where u_id='" + txt_uname.Text + "' and u_pass='" + txt_pass.Text + "'";
            SqlCommand cmd = new SqlCommand(abc, c.con);
            SqlDataReader dr = cmd.ExecuteReader();            
            if (dr.Read())
            {
                if (dr["u_block"].ToString() == "y")
                {
                    ViewState["per"] = "No Permission...Please Contact to administrator";
                    goto done;
                }
                if (dr["u_block"].ToString() == "n")
                {
                    Session["uid"] = txt_uname.Text;
                    Session["uname"] = dr["u_fname"].ToString();
                    Response.Redirect("ulogmain.aspx");
                }
            done:
                Label4.Visible = true;
                Label4.Text = ViewState["per"].ToString();
            }
            else
            {
                Label4.Visible = true;
                Label4.Text = "Please enter correct ID & Password";
            }
            dr.Close();
            c.con.Close();
        }
    }
}
