using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class forum : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            gd();
        }
    }
    public void gd()
    {
        c.con.Open();
        string str = "select * from df_topic";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = e.Row.Cells[2].Text + "@secure.com";
            e.Row.Cells[1].Text = "<a href=opforum.aspx?dfid=" + e.Row.Cells[0].Text + ">" + e.Row.Cells[1].Text + "</a>".ToString();
        }
    }
}
