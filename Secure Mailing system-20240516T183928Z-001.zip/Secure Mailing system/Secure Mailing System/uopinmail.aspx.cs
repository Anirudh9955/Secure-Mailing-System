using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

public partial class opiumail : System.Web.UI.Page
{
    connct c=new connct ();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Request.QueryString["mid"] != null)
        {
            Label1.Visible = true;
            ViewState["a"] = Request.QueryString["mid"].ToString();
            fill();
        }
        else
        {
            Response.Redirect("ulogmain.aspx");
        }
        Label7.Visible = false;
    }
    public void fill()
    {
        c.con.Open();
        string abc = "select * from usr_mail where m_id=" + ViewState["a"];
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {            
            txt_mailto.Text = dr["m_sen"].ToString();
            txt_mailsub.Text = dr["m_sub"].ToString();
            Label7.Text = dr["m_att"].ToString();
            txt_dttm.Text = dr["m_dttm"].ToString();
            txt_mailmsg.Text = dr["m_rsamail"].ToString();
            ViewState["enc"] = dr["m_mail"].ToString();
            ViewState["mid"] = dr["m_id"].ToString();
            ViewState["mpass"] = dr["m_pass"].ToString();
        }
        if (Label7.Text == "n")
        {
            hl_att.Visible = false;
            Label7.Visible = false;
            hl_att.Visible = false;
            Label4.Visible = false;
        }
        else
        {
            string att = ConfigurationSettings.AppSettings["link"].ToString();            
            hl_att.Visible = true;
            hl_att.Text = Label7.Text;
            hl_att.NavigateUrl = "uopatt.aspx?mid=" + ViewState["mid"];
        }
        dr.Close();
        c.con.Close();
    }
    static public string EncodeTo64(string toEncode)
    {
        byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);
        string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
        return returnValue;
    } 
    static public string DecodeFrom64(string encodedData)
    {
        byte[] encodedDataAsBytes = System.Convert.FromBase64String(encodedData);
        string returnValue = System.Text.ASCIIEncoding.ASCII.GetString(encodedDataAsBytes);
        return returnValue;
    }
    public void qwe()
    {
        string myData = ViewState["enc"].ToString();
        string myDataEncoded = EncodeTo64(myData);
        string myDataUnencoded = DecodeFrom64(myData);
        txt_mailenmsg.Text = myDataUnencoded.ToString();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        chkpass();        
    }
    public void chkpass()
    {
        if (TextBox1.Text == ViewState["mpass"].ToString())
        {
            Label8.Visible = false;
            RSACryptoServiceProvider myrsa = new RSACryptoServiceProvider();
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();//Encode String to Convert to Bytes
            qwe();
            Button5.Enabled = false;
        }
        else
        {
            Label8.Visible = true;
            Label8.Text = "Password Not Match";
        }
    }
    
}
