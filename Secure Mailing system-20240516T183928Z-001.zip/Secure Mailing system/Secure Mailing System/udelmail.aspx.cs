using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class udelmail : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
       
        if (!Page.IsPostBack)
        {
            Label1.Visible = false;
        }
        if (Request.QueryString["mid"] != null)
        {
            c.con.Open();
            int i;
            string[] quid = Request.QueryString["mid"].Split(',');
            for (i = 0; i < quid.Length - 1; i++) ;
            int val = Convert.ToInt32(quid[i]);
            for (i = 0; i < quid.Length; i++)
            {
                Session["quid"] = quid[i].ToString();
                SqlCommand cmd = new SqlCommand("update usr_mail set m_type='t' where m_id= " + quid[i] + "", c.con);
                cmd.ExecuteNonQuery();
                if (i == 0)
                    Label1.Text += quid[i];
                else
                    Label1.Text += "," + quid[i];
            }
            c.con.Close();
            Response.Redirect("uinbox.aspx");
        }
        else
        {
            string ab = "n";
            Response.Redirect("uinbox.aspx?md=" + ab);
        }
    }
}
