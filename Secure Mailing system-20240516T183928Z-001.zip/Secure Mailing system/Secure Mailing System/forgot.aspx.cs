using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class forgot : System.Web.UI.Page
{
    connct c = new connct();    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Label1.Visible = false;
            txt_eid.Visible = false;
            RequiredFieldValidator1.Visible = false;
            Button1.Enabled = false;
            Label3.Visible = false;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string str = RadioButtonList1.SelectedValue;
        if (str == "y")
        {
            Label1.Visible = true;
            txt_eid.Visible = true;
            RequiredFieldValidator1.Visible = true;
            Button1.Enabled = true;
            Label3.Visible = true;
        }
        if (str == "n")
        {
            Label3.Visible = false;
            Label1.Visible = false;
            txt_eid.Visible = false;
            RequiredFieldValidator1.Visible = false;
            Button1.Enabled = true;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        chktext();
        string dmy= "" + ddl_date.Text + "/" + ddl_mon.SelectedValue + "/" + ddl_year.Text + "";
        if (Label5.Text == "y")
        {
            if (txt_eid.Visible == true)
            {
                ViewState["str123"] = "select * from user_det where u_id='" + txt_eid.Text + "' and u_pcode='" + txt_postal.Text + "' and u_dob='" + dmy + "'";
                fill();
            }
            if (txt_eid.Visible == false)
            {
                ViewState ["str123"] = "select * from user_det where u_pcode='" + txt_postal.Text + "' and u_dob='" + dmy + "'";
                fill();
            }            
        }
        else
        {
            Label5.Visible = true;
        }
    }
    public void fill()
    {
        c.con.Open();
        SqlCommand cmd = new SqlCommand(ViewState["str123"].ToString(), c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label5.Visible = true;
            Label5.Text = "Your ID is :-" + dr["u_id"].ToString() + "@secure.com ....&.... Password is :-" + dr["u_pass"].ToString() + "";
        }
        else
        {
            Label5.Visible = true;
            Label5.Text = "Sorry your details is not valid we can't provide you ID/Password..!!";
        }
        dr.Close();
        c.con.Close();
    }
    public void chktext()
    {
        if (Label5.Text != "")
        {
            Label5.Text = "";
        }
        if (ddl_date.Text == "n")
        {
            ViewState["text"] = "Select the Date";
            goto done;            
        }
        if (ddl_mon.Text == "n")
        {
            ViewState["text"] = "Select the Month";
            goto done;            
        }
        if (ddl_year.Text == "n")
        {
            ViewState["text"] = "Select the Year";
            goto done;            
        }
        if (ViewState["text"] == null)
        {
            ViewState["text"] = "y";
        }
        done:
            Label5.Visible = true;
            Label5.Text = ViewState["text"].ToString();
    }
}
