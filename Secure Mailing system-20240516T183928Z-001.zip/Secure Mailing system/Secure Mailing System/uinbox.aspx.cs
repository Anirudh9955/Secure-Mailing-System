using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;

public partial class uinbox : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uname"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Request.QueryString["md"] != null)
        {
            Label1.Visible = true;
            Label1.Text = "Please select the mail, to delete..!!";
        }
        if (!Page.IsPostBack)
        {
            Label1.Visible = false;
            gd();
        }
    }
    private void ToggleCheckState(bool checkState)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)row.FindControl("chk");
            if (cb != null)
                cb.Checked = checkState;
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ToggleCheckState(true);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        ToggleCheckState(false);
    }
    public void gd()
    {
        c.con.Open();
        string str = "select * from user_det, usr_mail where u_id='" + Session["uid"].ToString() + "' and m_type='i' and u_id=m_rec order by m_dttm desc";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);        
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        ck();
    }
    public void ck()
    {
        StringBuilder str = new StringBuilder();
        int a = 0; string quid = ""; int s = 0;
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            bool isChecked = ((CheckBox)row.FindControl("chk")).Checked;
            Response.Write(isChecked);
            if (isChecked)
            {
                s = Convert.ToInt32(((TextBox)row.FindControl("txt")).Text);
                if (a == 0)
                    quid += s;
                else
                    quid += "," + s;
                a = a + 1;
            }
        }
        if (quid == "")
        {
            string ab = "n";     
            Response.Redirect("uinbox.aspx?md=" + ab);
        }
        else
            Response.Redirect("udelmail.aspx?mid=" + quid);
    }    
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[3].Text = e.Row.Cells[3].Text + "@secure.com";
            e.Row.Cells[2].Text = "<a href=uopinmail.aspx?mid=" + e.Row.Cells[1].Text + ">" + e.Row.Cells[2].Text + "</a>".ToString();
        }
    }
}
