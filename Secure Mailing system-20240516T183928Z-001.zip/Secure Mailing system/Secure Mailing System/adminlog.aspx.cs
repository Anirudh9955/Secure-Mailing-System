using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;

public partial class adminlog : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Session["uid"].ToString() != "Admin")
        {
            Response.Redirect("login.aspx?log=n");
        }
        if (Request.QueryString["ud"] == "n")
        {
            Button1.Enabled = false;
            GridView1.Visible = false;
            Button1.Visible = false;
            Label3.Visible = true;
            Label3.Text = "Please Select the user to Block/Unblock";
        }
        if (!Page.IsPostBack)
        {
            Button1.Enabled = false;
            GridView1.Visible = false;
            Button1.Visible = false;
            Label3.Visible = false;
        }
    }
    public void gd()
    {
        
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[1].Text = e.Row.Cells[1].Text + "@secure.com";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ck();
    }
    public void ck()
    {
        StringBuilder str = new StringBuilder();
        int a = 0; string quid = ""; int s = 0;
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            bool isChecked = ((CheckBox)row.FindControl("chk")).Checked;
            Response.Write(isChecked);
            if (isChecked)
            {
                s = Convert.ToInt32(((TextBox)row.FindControl("txt")).Text);
                if (a == 0)
                    quid += s;
                else
                    quid += "," + s;
                a = a + 1;
            }
        }
        if (Button1.Text == "Block")
        {
            if (quid == "")
            {
                string ab = "n";
                Response.Redirect("adminlog.aspx?ud=" + ab);
            }
            else
                Response.Redirect("logchng.aspx?ubid=" + quid);
        }
        if (Button1.Text == "Unblock")
        {
            if (quid == "")
            {
                string ab = "n";
                Response.Redirect("adminlog.aspx?ud=" + ab);
            }
            else
            {
                string a12 = "logchng.aspx?unbid=" + quid.ToString();
                Response.Redirect(a12.ToString());
            }
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label3.Visible = false;
        Button1.Visible = true;
        Button1.Text = "Unblock";
        Button1.Enabled = true;
        Button3.Enabled = false;
        c.con.Open();
        GridView1.Visible = true;
        string str = "select * from user_det where u_block='y' order by u_dttm desc";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Label3.Visible = false;
        Button1.Visible = true;
        Button1.Text = "Block";
        Button1.Enabled = true;
        Button2.Enabled = false;
        GridView1.Visible = true;
        c.con.Open();
        string str = "select * from user_det where u_block='n' order by u_dttm desc";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }
}
