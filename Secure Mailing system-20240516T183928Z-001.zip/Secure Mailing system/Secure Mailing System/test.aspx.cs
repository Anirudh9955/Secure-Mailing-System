using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

public partial class test : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {       
       
    }
    protected void bttn_simple_Click(object sender, EventArgs e)
    {
        string s = TextBox4.Text;
        foreach (char c in s)
        {
            int a = 0;
            a = (byte)c;
            a = a + 2;
            char tot = (char)a;
            ViewState["a"] = tot;
            TextBox8.Text = TextBox8.Text + "" + ViewState["a"].ToString();
        }  
    }
    protected void bttn_ds_Click(object sender, EventArgs e)
    {
        TextBox3.Text = "";
        string s = TextBox8.Text;
        foreach (char c in s)
        {
            int a = 0;
            a = (byte)c;
            a = a - 2;
            char tot = (char)a;
            ViewState["ab"] = tot;
            TextBox5.Text = TextBox5.Text + "" + ViewState["ab"].ToString();
        }
    }  
    protected void bttn_rsa_Click(object sender, EventArgs e)
    {
        chk();

    }
    public void chk()
    {
        if ((txt_1pm.Text == "2" || txt_1pm.Text == "3" || txt_1pm.Text == "5" || txt_1pm.Text == "7" || txt_1pm.Text == "11" || txt_1pm.Text == "13" || txt_1pm.Text == "17" || txt_1pm.Text == "19") && (txt_2pm.Text == "2" || txt_2pm.Text == "3" || txt_2pm.Text == "5" || txt_2pm.Text == "7" || txt_2pm.Text == "11" || txt_2pm.Text == "13" || txt_2pm.Text == "17" || txt_2pm.Text == "19"))
        {
            if (txt_1pm.Text != txt_2pm.Text)
            {
                Label5.Visible = false;
                ViewState["rsapass"] = txt_pass.Text;
                RSACryptoServiceProvider myrsa = new RSACryptoServiceProvider();   
                System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();       
                Label4.Text = "";
                string data = txt_renc.Text;                  
                Byte[] newdata = encoding.GetBytes(data);                
                Byte[] encrypted = myrsa.Encrypt(newdata, false);                      
                for (int i = 0; i < encrypted.Length; i++)
                {
                    string s = encrypted[i].ToString();                    
                    Label4.Text = Label4.Text + s.ToString();                    
                }                
                TextBox2.Text = Label4.Text;
                Label5.Visible = false;
            }
            else
            {
                Label5.Visible = true;
                Label5.Text = "Both prime no should not same";
            }
        }
        else
        {            
            Label5.Visible = true;
            Label5.Text = "Please enter valid Prime no/Prime No less than 20";
        }
    }
    protected void bttn_drsa_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == ViewState["rsapass"].ToString())
        {
            RSACryptoServiceProvider myrsa = new RSACryptoServiceProvider();            
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            string data = txt_renc.Text;            
            Byte[] newdata = encoding.GetBytes(data);            
            Byte[] encrypted = myrsa.Encrypt(newdata, false);            
            for (int i = 0; i < encrypted.Length; i++)
            {
                string s = encrypted[i].ToString();
                Label4.Text = Label4.Text + s.ToString();
            }
            TextBox2.Text = Label4.Text;
            Label4.Text = "";
            Byte[] decrypted = myrsa.Decrypt(encrypted, false);            
            string dData = encoding.GetString(decrypted);             
            for (int i = 0; i < decrypted.Length; i++)
            {                
                string s1 = dData[i].ToString();
                Label4.Text = Label4.Text + s1.ToString();           
            }            
            TextBox3.Text = Label4.Text;
        }
        else
        {
            Label5.Visible = true;
            Label5.Text = "Password Not Match";
        }
    }
}