using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class uchgpwd : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] != null)
        {
            ViewState["uname"] = Session["uname"].ToString();
            fill();
        }
        else
        {
            Response.Redirect("login.aspx?log=n");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = "update user_det set u_pass='" + txt_npass.Text + "' where u_id='" + Session ["uid"] + "'";
        c.con.Open();
        SqlCommand cmd = new SqlCommand(str, c.con);
        cmd.ExecuteNonQuery();
        c.con.Close();
        Label3.Visible = true;
        Label3.Text = "Updated Successfully";
        Button1.Enabled = false;
    }
    public void fill()
    {
        string abc = "select * from user_det where u_id='" + Session["uid"] + "'";
        c.con.Open();
        SqlCommand cmd = new SqlCommand(abc, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        dr.Read();
        {
            txt_aname.Text = dr["u_id"].ToString();
            txt_opass.Text = dr["u_pass"].ToString();
        }
        c.con.Close();
    }
}
