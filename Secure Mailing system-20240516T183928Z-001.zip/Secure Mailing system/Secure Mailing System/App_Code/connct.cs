using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for connct
/// </summary>
public class connct
{
    public SqlConnection con;
    public connct()
    {
        con = new SqlConnection();
        con.ConnectionString = ConfigurationSettings.AppSettings["connect"].ToString();
        //
        // TODO: Add constructor logic here
        //
    }
}
