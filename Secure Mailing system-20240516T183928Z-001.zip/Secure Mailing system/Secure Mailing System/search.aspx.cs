using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class search : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            txt_eid.Text = "";
            txt_fname.Text = "";
            txt_lname.Text = "";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        chk();
        fillgd();
    }
    public void chk()
    {
        if (txt_fname.Text == "" && txt_lname.Text != "" && txt_eid.Text != "")
        {
            string str = "select * from user_det where u_lname='" + txt_lname.Text + "' and u_id='" + txt_eid.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text != "" && txt_lname.Text == "" && txt_eid.Text != "")
        {
            string str = "select * from user_det where u_fname='" + txt_fname.Text + "' and u_id='" + txt_eid.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text != "" && txt_lname.Text != "" && txt_eid.Text == "")
        {
            string str = "select * from user_det where u_fname='" + txt_fname.Text + "' and u_lname='" + txt_lname.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text != "" && txt_lname.Text != "" && txt_eid.Text != "")
        {
            string str = "select * from user_det where u_fname='" + txt_fname.Text + "' and u_lname='" + txt_lname.Text + "' and u_id='" + txt_eid.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text == "" && txt_lname.Text == "" && txt_eid.Text == "")
        {
            string str = "select * from user_det";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text != "" && txt_lname.Text == "" && txt_eid.Text == "")
        {
            string str = "select * from user_det where u_fname='" + txt_fname.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text == "" && txt_lname.Text != "" && txt_eid.Text == "")
        {
            string str = "select * from user_det where u_lname='" + txt_lname.Text + "'";
            ViewState["str"] = str.ToString();
        }
        if (txt_fname.Text == "" && txt_lname.Text == "" && txt_eid.Text != "")
        {
            string str = "select * from user_det where u_id='" + txt_eid.Text + "'";
            ViewState["str"] = str.ToString();
        }
    }
    public void fillgd()
    {
        c.con.Open();
        string abc = ViewState["str"].ToString();
        SqlDataAdapter ad = new SqlDataAdapter(abc, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[0].Text = e.Row.Cells[0].Text + "@secure.com";
    }
}
