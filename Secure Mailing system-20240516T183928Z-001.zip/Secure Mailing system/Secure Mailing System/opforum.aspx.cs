using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class opforum : System.Web.UI.Page
{
    connct c = new connct();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["dfid"] != null)
        {
            gd();
            abc();
        }
        else
        {
            Response.Redirect("forum.aspx");
            
        }
    }
    public void abc()
    {
        c.con.Open();
        string str = "select * from df_topic where dft_id= " + Request.QueryString["dfid"].ToString();
        SqlCommand cmd = new SqlCommand(str, c.con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label1.Text = "Topic :- " + dr["dft_topic"].ToString();
        }
        dr.Close();
        c.con.Close();
    }
    public void gd()
    {
        c.con.Open();
        string str = "select * from df_topic,df_views where dft_id=" + Request.QueryString["dfid"].ToString() + " and dft_id=dfv_dft_id order by dfv_id desc";
        SqlDataAdapter ad = new SqlDataAdapter(str, c.con);
        DataSet ds = new DataSet();
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        c.con.Close();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[2].Text = e.Row.Cells[2].Text + "@secure.com";
        }
    }
}
